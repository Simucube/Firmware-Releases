Important note about updating from previous beta version
--------------------------------------------------------

Use your current version of the configuration tool to 
set a profile with  100% strength and only after that
open this version of the SimuCUBE Configuration Tool to 
update firmware.

This is to make sure your IONI MMC value is set correctly.

---------------------------------------------------------
If you miss this step, a power cycle of the SimuCUBE after
the update is complete can also be used to reset the 
correct maximum MMC value on the IONI drive.
